####################################################################################################
####################################################################################################
#                                                                                                  #
# importing the libraries                                                                          #
#                                                                                                  #
####################################################################################################
####################################################################################################



import numpy as np
import jax
import jax.numpy as jnp
import optax
import math
from typing import Optional, Tuple, Dict

import J_sampler



####################################################################################################
####################################################################################################
#                                                                                                  #
# some utilities                                                                                   #
#                                                                                                  #
####################################################################################################
####################################################################################################



def _compute_lambda(alpha, n_spins, n_samples):
    """ compute the regularization strength lambda from the user-supplied coefficient alpha """


    return alpha * math.sqrt(math.log((n_spins ** 2) / 0.05) / n_samples)



####################################################################################################
####################################################################################################
#                                                                                                  #
# loss functions written in spin-centric notation                                                  #
#                                                                                                  #
####################################################################################################
####################################################################################################



def _mpf_loss(h):
    """
    l_mpf ∝ exp(-ΔE / 2) with ΔE = 2h in the node-centric notation,
    hence exp(-h)
    """


    return jnp.exp(-h)  # equivalent to rise when written per‑node



####################################################################################################



def _logrise_loss(h):
    """
    log-rise loss: same exponential inside, the log is taken in the caller
    """


    return jnp.exp(-h)



####################################################################################################



def _rple_loss(h):
    """
    rple loss: log(1 + exp(-2h))
    """

    
    return jnp.log1p(jnp.exp(-2.0 * h))



####################################################################################################



def _rm_loss(h):
    """
        g^2(exp(2 * h)), with g(t) = 1/(t + 1)
    """


    return (1/(1+jnp.exp(2 * h)))**2



####################################################################################################
####################################################################################################
#                                                                                                  #
# reconstruct single spin, no emht                                                                 #
#                                                                                                  #
####################################################################################################
####################################################################################################



def _reconstruct_single_spin(
    s,
    freq,
    configs,
    method,
    lam,
    adj_row: Optional[jnp.ndarray] = None,
    n_steps=500,
    lr=1e-2,
    record_history=False,
):
    """
    Single-spin reconstruction with L1, JAX-friendly (no dynamic shapes).
    """


    # sizes and counts
    num_conf, num_spins = configs.shape

    # target spin
    y = configs[:, s]
    n_samples = freq.sum()

    # nodal statistics
    nodal_stat = (y[:, None] * configs).at[:, s].set(y).astype(jnp.float32)

    # adjacency hard zeros
    zero_mask = (
        (adj_row == 0) & (jnp.arange(num_spins) != s)
        if adj_row is not None
        else jnp.zeros(num_spins, dtype=bool)
    )

    # l1 mask: no penalty on self, no penalty on hard-zero entries (since they’re fixed zero)
    base_l1 = jnp.ones(num_spins, dtype=jnp.float32).at[s].set(0.0)
    l1_mask = base_l1 * (~zero_mask).astype(jnp.float32)

    # trainable mask: 1 for parameters we want to learn, 0 for fixed zeros
    train_mask = (~zero_mask).astype(jnp.float32)

    is_logrise = (method == "logRISE")

    # per-sample loss; w_full is always shape (num_spins,)
    def loss_smooth(w_full_raw):
        # enforce hard zeros via mask (no need to change dimension)
        w_full = w_full_raw * train_mask

        h = nodal_stat @ w_full

        if method == "MPF":
            return (freq / n_samples * _mpf_loss(h)).sum()
        elif method == "logRISE":
            return jnp.log((freq / n_samples * _logrise_loss(h)).sum())
        elif method == "RPLE":
            return (freq / n_samples * _rple_loss(h)).sum()
        elif method == "RM":
            return (freq / n_samples * _rm_loss(h)).sum()
        else:
            raise ValueError(f"unknown method: {method}")

    # full loss (all data) with L1
    def objective(w_full_raw):
        w_full = w_full_raw * train_mask
        data_loss = loss_smooth(w_full)
        l1_term = lam * jnp.sum(l1_mask * jnp.abs(w_full))
        return data_loss + l1_term

    # initialize full parameter vector
    params = jnp.zeros((num_spins,), dtype=jnp.float32)

    # Adam optimizer
    optimizer = optax.adam(learning_rate=lr)
    opt_state = optimizer.init(params)

    history = []

    # optimization loop
    for t in range(1, n_steps + 1):
        val, grads = jax.value_and_grad(objective)(params)
        updates, opt_state = optimizer.update(grads, opt_state, params)
        params = optax.apply_updates(params, updates)

        # re-apply hard zeros explicitly (not strictly needed if train_mask is used everywhere,
        # but it’s nice for numerical cleanliness and when inspecting params)
        params = params * train_mask

        if record_history:
            history.append(params)

    # final weights with hard zeros enforced
    w_full_final = params * train_mask

    if record_history:
        hist_arr = jnp.stack(history, axis=0)
    else:
        hist_arr = None

    return w_full_final, hist_arr



####################################################################################################
####################################################################################################
#                                                                                                  #
# reconstruct single spin with emht                                                                #
#                                                                                                  #
####################################################################################################
####################################################################################################



def _reconstruct_single_spin_em(s, freq, configs, eps = 0.01, lam = 0.1, adj_row: Optional[jnp.ndarray] = None, n_steps = 500, lr = 1e-2, record_history = False):
    """
    erasure machine version of the previous function
    """


    # sizes and counts
    num_conf, num_spins = configs.shape
    n_samples = freq.sum()

    # target spin column
    y = configs[:, s]

    # nodewise statistics
    nodal_stat = (y[:, None] * configs).at[:, s].set(y).astype(jnp.float32)

    # hard-zero mask from adjacency
    zero_mask = (
        (adj_row == 0) & (jnp.arange(num_spins) != s)
        if adj_row is not None
        else jnp.zeros(num_spins, dtype=bool)
    )

    # initialize weights to zero
    w_full = jnp.zeros(num_spins, dtype=jnp.float32)

    # l1 proximal operator on off-diagonal entries
    def prox_l1_offdiag(w, tau):
        # keep self untouched
        off = w.at[s].set(0.0)
        # soft-threshold off-diagonal
        shrunk = jnp.sign(off) * jnp.maximum(jnp.abs(off) - tau, 0.0)
        # restore self
        return shrunk.at[s].set(w[s])

    # adam optimizer
    optimizer = optax.adam(learning_rate=lr)
    opt_state = optimizer.init(w_full)

    # optional trajectory
    history = []

    # em-style updates
    for t in range(1, n_steps + 1):
        # local field h_s(x) = stats · w
        h = nodal_stat @ w_full

        # e-step: tempered by eps
        local_logw = -(1.0 - eps) * h
        r_unnorm = (freq / n_samples) * jnp.exp(local_logw - jnp.max(local_logw))  # stabilize
        r = r_unnorm / (r_unnorm.sum() + 1e-12)  # normalize

        # data moments under r
        data_m_s = (r * y).sum()                  # first moment for node s
        data_C_sj = (r[:, None] * nodal_stat).sum(axis=0)  # cross terms

        # model moments (simple linearized form)
        model_m_s = eps * w_full[s]
        model_C_sj = eps * w_full

        # gradient of m-step objective
        grad = jnp.zeros_like(w_full)
        grad = grad.at[s].set(data_m_s - model_m_s)  # self term
        grad = grad + (data_C_sj - model_C_sj) * (jnp.arange(num_spins) != s)  # off-diag

        # adam step (maximize, hence minus grad in update call)
        updates, opt_state = optimizer.update(-grad, opt_state, w_full)
        w_full = optax.apply_updates(w_full, updates)

        # l1 prox on off-diagonals if requested
        if lam > 0.0:
            w_full = prox_l1_offdiag(w_full, tau=lr * lam)

        # enforce hard zeros from adjacency
        if adj_row is not None:
            w_full = w_full.at[zero_mask].set(0.0)

        # record iterate
        if record_history:
            history.append(w_full)

    # return final weights and history
    if record_history:
        hist_arr = jnp.stack(history, axis=0)
    else:
        hist_arr = None

    return w_full, hist_arr



####################################################################################################
####################################################################################################
#                                                                                                  #
# inverse ising                                                                                    #
#                                                                                                  #
####################################################################################################
####################################################################################################



def _log_pseudolikelihood(J, samples):
    """ log-pseudolikelihood """

    samples = jnp.asarray(samples)
    n_out, num_spins = samples.shape

    logpl_total = 0.0

    for s in range(num_spins):
        y = samples[:, s]
        nodal_stat = (y[:, None] * samples).at[:, s].set(y).astype(jnp.float32)
        h = nodal_stat @ J[s, :]

        logpl_s = (h - jnp.log(2.0 * jnp.cosh(h))).sum()
        logpl_total = logpl_total + logpl_s

    return float(logpl_total)



####################################################################################################



def _oos_loss_logpseudolikelihood(J, samples_out):
    """ loss out of samples """


    samples_out = jnp.asarray(samples_out)
    n_out, num_spins = samples_out.shape

    logpl = _log_pseudolikelihood(J, samples_out)
    neg_logpl_per_sample_spin = -logpl / (n_out * num_spins)

    return float(neg_logpl_per_sample_spin)



####################################################################################################



def inverse_ising(
    method,
    regularizing_value,
    symmetrization,
    samples,
    samples_out,
    adj = None,
    n_steps = 500,
    eps = 0.1,
    lr = 1e-2,
    record_history = True
    ):
    """ inverse ising """

    method = method.strip()
    symmetrization = symmetrization.strip().upper()

    samples = jnp.asarray(samples)
    n_samples, num_spins = samples.shape
    num_samples_float = float(n_samples)

    lam = _compute_lambda(regularizing_value, num_spins, num_samples_float)
    print(f"λ = {lam:.5g}  (reg = {regularizing_value})")

    W_snapshots: Dict[int, np.ndarray] = {}
    freq = jnp.ones((n_samples,), dtype=jnp.int32)/n_samples
    configs = samples

    spins = jnp.arange(num_spins)

    if method == "EMHT":

        if adj is None:
            if record_history:
                def _worker(s):
                    return _reconstruct_single_spin_em(
                        s, freq, configs, eps, lam, None,
                        n_steps=n_steps, lr=lr,
                        record_history=True,
                    )
                rows, H = jax.vmap(_worker)(spins)
            else:
                def _worker(s):
                    w, _ = _reconstruct_single_spin_em(
                        s, freq, configs, eps, lam, None,
                        n_steps=n_steps, lr=lr,
                        record_history=False,
                    )
                    return w
                rows = jax.vmap(_worker)(spins)
                H = None
        else:
            adj_rows = jnp.asarray(adj)
            if record_history:
                def _worker(s, adj_row):
                    return _reconstruct_single_spin_em(
                        s, freq, configs, eps, lam, adj_row,
                        n_steps=n_steps, lr=lr,
                        record_history=True,
                    )
                rows, H = jax.vmap(_worker, in_axes=(0,0))(spins, adj_rows)
            else:
                def _worker(s, adj_row):
                    w, _ = _reconstruct_single_spin_em(
                        s, freq, configs, eps, lam, adj_row,
                        n_steps=n_steps, lr=lr,
                        record_history=False,
                    )
                    return w
                rows = jax.vmap(_worker, in_axes=(0,0))(spins, adj_rows)
                H = None

    else:

        if adj is None:
            if record_history:
                def _worker(s):
                    return _reconstruct_single_spin(
                        s, freq, configs, method, lam, None,
                        n_steps=n_steps, lr=lr,
                        record_history=True,
                    )
                rows, H = jax.vmap(_worker)(spins)
            else:
                def _worker(s):
                    w, _ = _reconstruct_single_spin(
                        s, freq, configs, method, lam, None,
                        n_steps=n_steps, lr=lr,
                        record_history=False,
                    )
                    return w
                rows = jax.vmap(_worker)(spins)
                H = None
        else:
            adj_rows = jnp.asarray(adj)
            if record_history:
                def _worker(s, adj_row):
                    return _reconstruct_single_spin(
                        s, freq, configs, method, lam, adj_row,
                        n_steps=n_steps, lr=lr,
                        record_history=True,
                    )
                rows, H = jax.vmap(_worker, in_axes=(0,0))(spins, adj_rows)
            else:
                def _worker(s, adj_row):
                    w, _ = _reconstruct_single_spin(
                        s, freq, configs, method, lam, adj_row,
                        n_steps=n_steps, lr=lr,
                        record_history=False,
                    )
                    return w
                rows = jax.vmap(_worker, in_axes=(0,0))(spins, adj_rows)
                H = None

    W = rows

    if record_history and H is not None:
        H_np = np.asarray(H)
        _, T, _ = H_np.shape
        for step in range(T):
            W_snapshots[step] = H_np[:, step, :].astype(np.float32)

    if symmetrization == "Y":
        W = 0.5 * (W + W.T)
        if record_history:
            for k in list(W_snapshots.keys()):
                W_snapshots[k] = 0.5 * (W_snapshots[k] + W_snapshots[k].T)

    if samples_out is not None:
        print("Selecting best snapshot by out-of-sample log-pseudolikelihood...")

        best_W = W
        best_loss = _oos_loss_logpseudolikelihood(best_W, samples_out)
        best_step = None

        if record_history and len(W_snapshots) > 0:
            for k, W_k_np in W_snapshots.items():
                W_k = jnp.asarray(W_k_np, dtype=jnp.float32)
                loss_k = _oos_loss_logpseudolikelihood(W_k, samples_out)

                if loss_k < best_loss:
                    best_loss = loss_k
                    best_W = W_k
                    best_step = k

        if best_step is not None:
            print(f"  -> selected snapshot at step {best_step} ")
        else:
            print(f"  -> final weights already best with OOS -logPL = {best_loss:.6g}")

        W = best_W

    W_np = np.asarray(W)
    history = {int(k): np.asarray(v) for k, v in W_snapshots.items()}

    return W_np, history



####################################################################################################



def inverse_ising_old(method, regularizing_value, symmetrization, histogram, adj = None, n_steps = 500, eps = 0.1, lr = 1e-2, record_history = False):
    """ returns the inferred matrix J """


    method = method.strip()
    symmetrization = symmetrization.strip().upper()

    freq, configs = J_sampler._histogram_to_freq_configs(histogram)
    num_conf, num_spins = configs.shape
    num_samples = float(freq.sum())
    n_samples = freq.sum()


    lam = _compute_lambda(regularizing_value, num_spins, num_samples)
    print(f"λ = {lam:.5g}  (reg = {regularizing_value})")


    W_snapshots: Dict[int, np.ndarray] = {}

    rows = []


    if method == "EMHT":
        for s in range(num_spins):
            print(f"[{s+1}/{num_spins}] reconstruction spin {s}")
            adj_row = adj[s] if adj is not None else None
            w_row_final, hist_row = _reconstruct_single_spin_em(
                s, freq, configs, eps, lam, adj_row,
                n_steps=n_steps, lr=lr,
                record_history=record_history,
            )
            rows.append(w_row_final)

            if record_history:
                for step, w_vec in enumerate(hist_row):
                    if step not in W_snapshots:
                        W_snapshots[step] = np.zeros((num_spins, num_spins), dtype=np.float32)
                    W_snapshots[step][s, :] = np.asarray(w_vec, dtype=np.float32)

        W = jnp.stack(rows)

    else:
        for s in range(num_spins):
            print(f"[{s+1}/{num_spins}] reconstruction spin {s}")
            adj_row = adj[s] if adj is not None else None
            w_row_final, hist_row = _reconstruct_single_spin(
                s, freq, configs, method, lam, adj_row,
                n_steps=n_steps, lr=lr,
                record_history=record_history,
            )
            rows.append(w_row_final)

            if record_history:
                for step, w_vec in enumerate(hist_row):
                    if step not in W_snapshots:
                        W_snapshots[step] = np.zeros((num_spins, num_spins), dtype=np.float32)
                    W_snapshots[step][s, :] = np.asarray(w_vec, dtype=np.float32)

        W = jnp.stack(rows)

    if symmetrization == "Y":
        W = 0.5 * (W + W.T)
        if record_history:
            for k in list(W_snapshots.keys()):
                W_snapshots[k] = 0.5 * (W_snapshots[k] + W_snapshots[k].T)

    W_np = np.asarray(W)

    history = {int(k): np.asarray(v) for k, v in W_snapshots.items()}

    return W_np, history

