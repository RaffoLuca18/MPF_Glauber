####################################################################################################
####################################################################################################
#                                                                                                  #
# importing the libraries                                                                          #
#                                                                                                  #
####################################################################################################
####################################################################################################



import numpy as np
import jax.numpy as jnp
import math
import matplotlib.pyplot as plt

import J_inference
import J_sampler
import GGM_sampler
import GGM_inference
import GGM_diagnostics


####################################################################################################
####################################################################################################
#                                                                                                  #
# some utilities                                                                                   #
#                                                                                                  #
####################################################################################################
####################################################################################################



def mask(J, t = 0.1):
    """ masking everything under t to zero and everything above to one """


    n_spins = J.shape[0]
    mask = (jnp.abs(J) >= t).astype(jnp.float32)

    return mask



####################################################################################################



def mask_prec(precision_hat, el):
    """ i mask low entries and i keep the high ones unchanged. """


    return jnp.where(jnp.abs(precision_hat) < el, 0.0, precision_hat)



####################################################################################################



def continuous_to_sign(samples_cont):


    samples_cont = jnp.asarray(samples_cont)
    samples_sign = jnp.sign(samples_cont)
    samples_sign = jnp.where(samples_sign == 0, 1, samples_sign)

    return samples_sign



####################################################################################################



def roc_prc(true_J, hat_J, thresholds = None):
    """ ROC curve + AUC, PRC curve + AUC-PR, and PR baseline for edge selection """


    n_spins = true_J.shape[0]

    true_edges = (jnp.abs(true_J) > 1e-12).astype(jnp.float32)
    true_edges = true_edges * (1.0 - jnp.eye(n_spins))
    true_edges = jnp.maximum(true_edges, true_edges.T)

    upper = jnp.triu(jnp.ones((n_spins, n_spins), dtype=jnp.float32), k=1)
    P = jnp.sum(true_edges * upper)          
    N = jnp.sum((1.0 - true_edges) * upper) 
    pr_baseline = P / jnp.maximum(P + N, 1.0)

    # thresholds grid
    if thresholds is None:
        maxval = float(jnp.max(jnp.abs(hat_J)))
        thresholds = jnp.linspace(0.0, maxval, 50)

    fpr_list, tpr_list = [], []
    precision_list, recall_list = [], []

    for t in thresholds:
        est_edges = (jnp.abs(hat_J) > t).astype(jnp.float32)
        est_edges = est_edges * (1.0 - jnp.eye(n_spins))
        est_edges = jnp.maximum(est_edges, est_edges.T)

        TP = jnp.sum((true_edges == 1) & (est_edges == 1))
        FP = jnp.sum((true_edges == 0) & (est_edges == 1))
        FN = jnp.sum((true_edges == 1) & (est_edges == 0))
        TN = jnp.sum((true_edges == 0) & (est_edges == 0))

        TPR = TP / jnp.maximum(TP + FN, 1.0)  # recall
        FPR = FP / jnp.maximum(FP + TN, 1.0)
        PREC = TP / jnp.maximum(TP + FP, 1.0)
        REC = TPR

        fpr_list.append(FPR)
        tpr_list.append(TPR)
        precision_list.append(PREC)
        recall_list.append(REC)

    # arrays
    fpr = jnp.array(fpr_list)
    tpr = jnp.array(tpr_list)
    precision = jnp.array(precision_list)
    recall = jnp.array(recall_list)

    # add ROC endpoints
    fpr = jnp.concatenate([jnp.array([0.0]), fpr, jnp.array([1.0])])
    tpr = jnp.concatenate([jnp.array([0.0]), tpr, jnp.array([1.0])])

    # add PRC endpoints (precision=1 at recall=0 by convention)
    precision = jnp.concatenate([jnp.array([1.0]), precision])
    recall = jnp.concatenate([jnp.array([0.0]), recall])

    # sort
    roc_idx = jnp.argsort(fpr)
    fpr, tpr = fpr[roc_idx], tpr[roc_idx]

    prc_idx = jnp.argsort(recall)
    recall, precision = recall[prc_idx], precision[prc_idx]

    # AUC via trapezoid
    auc_roc = np.trapezoid(tpr, fpr)
    auc_prc = np.trapezoid(precision, recall)

    # return also the PR baseline
    return fpr, tpr, auc_roc, recall, precision, auc_prc, float(pr_baseline)



####################################################################################################
####################################################################################################
#                                                                                                  #
# recepy                                                                                           #
#                                                                                                  #
####################################################################################################
####################################################################################################



def log_pseudolikelihood(samples, J, beta = 1.0):
    """ log-pseudolikelihood estimator """


    # local field
    h = samples @ J.T - samples * jnp.diag(J)  

    # logits = 2β s_r h_r
    logits = 2.0 * beta * samples * h

    # log p(s_r | s_{-r}) = -log(1 + exp(-logits))
    log_cond_probs = -jnp.logaddexp(0.0, -logits)

    return jnp.mean(jnp.sum(log_cond_probs, axis=1))



####################################################################################################



def bic_procedure(samples, samples_out, J_hat, method, symmetrization, n_steps=200, early_stop=1.0):


    n_samples = len(samples)
    n_samples_out = len(samples_out)
    abs_val = jnp.sort(jnp.abs(J_hat).ravel())[::-1].tolist()
    k = math.ceil(early_stop * len(abs_val))
    abs_val = abs_val[:k]

    score = jnp.inf
    J_ret = J_hat
    bic = []
    maskeds = []

    for el in abs_val:
        mask_hat = mask_prec(J_hat, el)
        maskeds.append(mask_hat)
        score_try = (-2) * n_samples_out * log_pseudolikelihood(samples_out, mask_hat) + jnp.log(n_samples_out) * jnp.sum(mask(mask_hat, el))
        bic.append(score_try)
        if score_try < score:
            score = score_try
            J_ret = mask_hat

    # J_refit, _ = J_inference.inverse_ising(method, 0.0, symmetrization, samples, samples_out, adj=mask(J_ret, 1e-10), n_steps=n_steps)

    return J_ret, bic, score, maskeds



####################################################################################################



def recepy(method, regularizing_value, symmetrization, histogram, n_steps=200, early_stop=1.0):


    samples = J_sampler._histogram_to_samples(histogram)
    J_hat, _ = J_inference.inverse_ising(method, regularizing_value, symmetrization, histogram, n_steps=n_steps)

    return bic_procedure(samples, J_hat, method, symmetrization, n_steps=n_steps, early_stop=early_stop)



####################################################################################################



def recepy_staged_discrete(
    samples_cont,
    method,
    regularizing_value,
    symmetrization,
    n_steps=200,
    early_stop=1.0,
    n_stages=20,
):
    

    n_total = len(samples_cont)
    stage_sizes = [math.ceil((k / n_stages) * n_total) for k in range(1, n_stages + 1)]
    results = []
    samples = continuous_to_sign(samples_cont)

    for n_used in stage_sizes:
        S_sub = samples[:n_used]
        S_sub_cont = samples_cont[:n_used]
        J_hat, _ = J_inference.inverse_ising(method, regularizing_value, symmetrization, J_sampler._samples_to_histogram(S_sub), n_steps=n_steps)
        J_ret, bic, score = bic_procedure(S_sub, J_hat, method, symmetrization, n_steps=n_steps, early_stop=early_stop)
        results.append((n_used, J_ret, bic, score, S_sub_cont))

    return results



####################################################################################################



def bic_gaussian_on_minusJ_plus_I(samples_cont, J_ret):
    n = len(samples_cont)
    P = -J_ret + jnp.eye(J_ret.shape[0])
    P_pd = GGM_inference._project_to_pd(P)
    k = jnp.count_nonzero(P_pd)
    return (-2) * GGM_diagnostics.loglikelihood_gaussian(samples_cont, P_pd) + jnp.log(n) * (k / 2)